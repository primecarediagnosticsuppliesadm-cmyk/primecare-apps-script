/************************************************************
 * 12_Web_UI.gs
 * PrimeCare web UI backend
 ************************************************************/

function openStockDashboard() {
  const html = HtmlService
    .createHtmlOutputFromFile("PrimeCare_Stock_Dashboard")
    .setTitle("PrimeCare Stock Dashboard");
  SpreadsheetApp.getUi().showSidebar(html);
}

function openAgentUpdatesPage() {
  const html = HtmlService
    .createHtmlOutputFromFile("PrimeCare_Agent_Updates")
    .setTitle("PrimeCare Agent Updates");
  SpreadsheetApp.getUi().showSidebar(html);
}

function doGet(e) {
  const page = (e && e.parameter && e.parameter.page) ? e.parameter.page : "agent";

  if (page === "stock") {
    return HtmlService
      .createHtmlOutputFromFile("PrimeCare_Stock_Dashboard")
      .setTitle("PrimeCare Stock Dashboard")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }

  return HtmlService
    .createHtmlOutputFromFile("PrimeCare_Agent_Updates")
    .setTitle("PrimeCare Agent Updates")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function pcwebGetStockDashboardData() {
  const inventory = pcaiSheetExists_(PCAI_SHEETS.INVENTORY)
    ? pcaiGetRowsAsObjects_(pcaiGetSheetRequired_(PCAI_SHEETS.INVENTORY), "Product_ID")
    : [];

  const collectionsRisk = pcaiSheetExists_(PCAI_SHEETS.COLLECTIONS_RISK)
    ? pcaiGetRowsAsObjects_(pcaiGetSheetRequired_(PCAI_SHEETS.COLLECTIONS_RISK), "Lab_ID")
    : [];

  const reorderItems = inventory
    .map(r => {
      const current = pcaiNum_(r.Current_Stock);
      const min = pcaiNum_(r.Min_Stock);
      const reorderQty = pcaiNum_(r.Reorder_Qty);
      const status = String(r.Reorder_Status || "").trim().toUpperCase();

      let stockHealth = "Healthy";
      if (current <= 0) stockHealth = "Critical";
      else if (current < min) stockHealth = "Reorder";

      return {
        productId: String(r.Product_ID || "").trim(),
        productName: String(r.Product_Name || "").trim(),
        category: String(r.Category || "").trim(),
        currentStock: current,
        minStock: min,
        reorderQty: reorderQty,
        reorderStatus: status,
        avgDailySales: pcaiNum_(r.Avg_Daily_Sales_30D),
        leadTimeDays: pcaiNum_(r.Lead_Time_Days),
        stockHealth: stockHealth
      };
    })
    .filter(x => x.productId);

  const stats = {
    totalSkus: reorderItems.length,
    criticalItems: reorderItems.filter(x => x.stockHealth === "Critical").length,
    reorderItems: reorderItems.filter(x => x.stockHealth === "Reorder").length,
    healthyItems: reorderItems.filter(x => x.stockHealth === "Healthy").length,
    totalSuggestedOrderQty: reorderItems.reduce((sum, x) => sum + (x.stockHealth !== "Healthy" ? x.reorderQty : 0), 0),
    labsAtCollectionsRisk: collectionsRisk.length
  };

  return {
    stats: stats,
    inventory: reorderItems.sort((a, b) => {
      const rank = { Critical: 1, Reorder: 2, Healthy: 3 };
      return (rank[a.stockHealth] || 99) - (rank[b.stockHealth] || 99);
    }).slice(0, 200)
  };
}

function pcwebGetAgentVisitSeedData() {
  const labs = pcaiSheetExists_(PCAI_SHEETS.AR)
    ? pcaiGetRowsAsObjects_(pcaiGetSheetRequired_(PCAI_SHEETS.AR), "Lab_ID")
    : [];

  return {
    labs: labs.map(r => ({
      labId: String(r.Lab_ID || "").trim(),
      labName: String(r.Lab_Name || "").trim() || String(r.Lab_ID || "").trim()
    })).filter(x => x.labId)
  };
}

function pcwebSaveAgentVisit(formData) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Agent_Visit_Log");
  if (!sh) throw new Error("Missing required sheet: Agent_Visit_Log");

  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(h => String(h || "").trim());

  const visitId = "VIS-" + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMdd-HHmmss");

  const rowObj = {
    Visit_ID: visitId,
    Visit_Date: formData.visitDate || new Date(),
    Agent_Name: formData.agentName || "",
    Lab_ID: formData.labId || "",
    Lab_Name: formData.labName || "",
    Area: formData.area || "",
    Visit_Type: formData.visitType || "",
    Samples_Given: Number(formData.samplesGiven || 0),
    Demo_Given: formData.demoGiven || "No",
    Lab_Response: formData.labResponse || "",
    Sold_Value: Number(formData.soldValue || 0),
    Stock_Available: formData.stockAvailable || "",
    Needs_New_Stock: formData.needsNewStock || "",
    Next_Action: formData.nextAction || "",
    Notes: formData.notes || "",
    Created_At: new Date()
  };

  const row = headers.map(h => rowObj[h] !== undefined ? rowObj[h] : "");
  sh.appendRow(row);

  return "Agent visit saved successfully with Visit_ID: " + visitId;
}
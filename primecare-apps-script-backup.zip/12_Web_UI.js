/************************************************************
 * 12_Web_UI.gs
 * PrimeCare web UI backend
 ************************************************************/

function openStockDashboard() {
  const html = HtmlService
    .createHtmlOutputFromFile("PrimeCare_Stock_Dashboard")
    .setTitle("PrimeCare Stock Dashboard");
  SpreadsheetApp.getUi().showSidebar(html);
}

function openAgentUpdatesPage() {
  const html = HtmlService
    .createHtmlOutputFromFile("PrimeCare_Agent_Updates")
    .setTitle("PrimeCare Agent Updates");
  SpreadsheetApp.getUi().showSidebar(html);
}

/************************************************************
 * 12_Web_UI.gs
 * PrimeCare web app entry + current UI backend
 ************************************************************/

/************************************************************
 * 12_Web_UI.gs
 * PrimeCare API bridge for React
 ************************************************************/

function doGet(e) {
  const action = getParam_(e, "action");
  const page = getParam_(e, "page");

  // JSON API routes
  if (action) {
    return handleApiGet_(e);
  }

  // Temporary legacy page routing (can stay for now)
  if (page === "stock") {
    return HtmlService
      .createHtmlOutputFromFile("PrimeCare_Stock_Dashboard")
      .setTitle("PrimeCare Stock Dashboard")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }

  if (page === "agent" || !page) {
    return HtmlService
      .createHtmlOutputFromFile("PrimeCare_Agent_Updates")
      .setTitle("PrimeCare Agent Updates")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }

  return jsonOutput_({
    success: false,
    error: "Invalid request"
  });
}

function doPost(e) {
  return handleApiPost_(e);
}

function handleApiGet_(e) {
  try {
    const action = getParam_(e, "action");

    if (action === "getStock") {
      return jsonOutput_({
        success: true,
        data: pcwebGetStockDashboardData()
      });
    }

    if (action === "getLabs") {
      return jsonOutput_({
        success: true,
        data: pcwebGetAgentVisitSeedData()
      });
    }

    if (action === "getDashboard") {
      return jsonOutput_({
        success: true,
        data: pcwebGetDashboardSummary_()
      });
    }

    return jsonOutput_({
      success: false,
      error: "Unknown GET action: " + action
    });
  } catch (err) {
    return jsonOutput_({
      success: false,
      error: err.message
    });
  }
}

function handleApiPost_(e) {
  try {
    const action = getParam_(e, "action");
    const body = parseJsonBody_(e);

    if (action === "saveAgentVisit") {
      const result = pcwebSaveAgentVisit(body || {});
      return jsonOutput_({
        success: true,
        data: result
      });
    }

    return jsonOutput_({
      success: false,
      error: "Unknown POST action: " + action
    });
  } catch (err) {
    return jsonOutput_({
      success: false,
      error: err.message
    });
  }
}

/************************************************************
 * Helpers
 ************************************************************/

function getParam_(e, key) {
  return e && e.parameter && e.parameter[key]
    ? String(e.parameter[key]).trim()
    : "";
}

function parseJsonBody_(e) {
  if (!e || !e.postData || !e.postData.contents) {
    return {};
  }

  try {
    return JSON.parse(e.postData.contents);
  } catch (err) {
    throw new Error("Invalid JSON body");
  }
}

function jsonOutput_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function pcwebGetStockDashboardData() {
  const inventory = pcaiSheetExists_(PCAI_SHEETS.INVENTORY)
    ? pcaiGetRowsAsObjects_(pcaiGetSheetRequired_(PCAI_SHEETS.INVENTORY), "Product_ID")
    : [];

  const collectionsRisk = pcaiSheetExists_(PCAI_SHEETS.COLLECTIONS_RISK)
    ? pcaiGetRowsAsObjects_(pcaiGetSheetRequired_(PCAI_SHEETS.COLLECTIONS_RISK), "Lab_ID")
    : [];

  const reorderItems = inventory
    .map(r => {
      const current = pcaiNum_(r.Current_Stock);
      const min = pcaiNum_(r.Min_Stock);
      const reorderQty = pcaiNum_(r.Reorder_Qty);
      const status = String(r.Reorder_Status || "").trim().toUpperCase();

      let stockHealth = "Healthy";
      if (current <= 0) stockHealth = "Critical";
      else if (current < min) stockHealth = "Reorder";

      return {
        productId: String(r.Product_ID || "").trim(),
        productName: String(r.Product_Name || "").trim(),
        category: String(r.Category || "").trim(),
        currentStock: current,
        minStock: min,
        reorderQty: reorderQty,
        reorderStatus: status,
        avgDailySales: pcaiNum_(r.Avg_Daily_Sales_30D),
        leadTimeDays: pcaiNum_(r.Lead_Time_Days),
        stockHealth: stockHealth
      };
    })
    .filter(x => x.productId);

  const stats = {
    totalSkus: reorderItems.length,
    criticalItems: reorderItems.filter(x => x.stockHealth === "Critical").length,
    reorderItems: reorderItems.filter(x => x.stockHealth === "Reorder").length,
    healthyItems: reorderItems.filter(x => x.stockHealth === "Healthy").length,
    totalSuggestedOrderQty: reorderItems.reduce((sum, x) => sum + (x.stockHealth !== "Healthy" ? x.reorderQty : 0), 0),
    labsAtCollectionsRisk: collectionsRisk.length
  };

  return {
    stats: stats,
    inventory: reorderItems.sort((a, b) => {
      const rank = { Critical: 1, Reorder: 2, Healthy: 3 };
      return (rank[a.stockHealth] || 99) - (rank[b.stockHealth] || 99);
    }).slice(0, 200)
  };
}

function pcwebGetAgentVisitSeedData() {
  const labs = pcaiSheetExists_(PCAI_SHEETS.AR)
    ? pcaiGetRowsAsObjects_(pcaiGetSheetRequired_(PCAI_SHEETS.AR), "Lab_ID")
    : [];

  return {
    labs: labs.map(r => ({
      labId: String(r.Lab_ID || "").trim(),
      labName: String(r.Lab_Name || "").trim() || String(r.Lab_ID || "").trim()
    })).filter(x => x.labId)
  };
}

function pcwebSaveAgentVisit(formData) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Agent_Visit_Log");
  if (!sh) throw new Error("Missing required sheet: Agent_Visit_Log");

  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function(h) {
    return String(h || "").trim();
  });

  const requiredHeaders = [
    "Visit_ID",
    "Visit_Date",
    "Agent_Name",
    "Lab_ID",
    "Lab_Name",
    "Area",
    "Visit_Type",
    "Samples_Given",
    "Demo_Given",
    "Lab_Response",
    "Sold_Value",
    "Stock_Available",
    "Needs_New_Stock",
    "Next_Action",
    "Notes",
    "Created_At"
  ];

  const missing = requiredHeaders.filter(function(h) {
    return headers.indexOf(h) === -1;
  });

  if (missing.length) {
    throw new Error("Agent_Visit_Log is missing headers: " + missing.join(", "));
  }

  if (!formData.agentName) throw new Error("Agent name is required");
  if (!formData.labName) throw new Error("Lab name is required");
  if (!formData.area) throw new Error("Area is required");

  const visitId = "VIS-" + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMdd-HHmmss");

  const rowObj = {
    Visit_ID: visitId,
    Visit_Date: formData.visitDate || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd"),
    Agent_Name: String(formData.agentName || "").trim(),
    Lab_ID: String(formData.labId || "").trim(),
    Lab_Name: String(formData.labName || "").trim(),
    Area: String(formData.area || "").trim(),
    Visit_Type: String(formData.visitType || "").trim(),
    Samples_Given: Number(formData.samplesGiven || 0),
    Demo_Given: String(formData.demoGiven || "No").trim(),
    Lab_Response: String(formData.labResponse || "").trim(),
    Sold_Value: Number(formData.soldValue || 0),
    Stock_Available: String(formData.stockAvailable || "").trim(),
    Needs_New_Stock: String(formData.needsNewStock || "").trim(),
    Next_Action: String(formData.nextAction || "").trim(),
    Notes: String(formData.notes || "").trim(),
    Created_At: new Date()
  };

  const row = headers.map(function(h) {
    return rowObj[h] !== undefined ? rowObj[h] : "";
  });

  sh.appendRow(row);

  return {
    visitId: visitId,
    message: "Agent visit saved successfully"
  };
}

function pcFixPurchaseOrdersSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName("Purchase_Orders");

  if (!sh) {
    sh = ss.insertSheet("Purchase_Orders");
  }

  const headers = [
    "PO_ID",
    "PO_Date",
    "Product_ID",
    "Product_Name",
    "Quantity",
    "Unit_Cost",
    "Total_Cost",
    "Supplier",
    "Status",
    "Created_At"
  ];

  sh.clearContents();
  sh.clearFormats();

  sh.getRange(1, 1, 1, headers.length).setValues([headers]);

  sh.getRange(1, 1, 1, headers.length)
    .setFontWeight("bold")
    .setBackground("#dbeafe")
    .setBorder(true, true, true, true, true, true);

  sh.setFrozenRows(1);

  const widths = [140, 120, 130, 220, 100, 110, 120, 180, 120, 180];
  widths.forEach((w, i) => sh.setColumnWidth(i + 1, w));

  const maxRows = Math.max(sh.getMaxRows(), 200);
  if (sh.getMaxRows() < maxRows) {
    sh.insertRowsAfter(sh.getMaxRows(), maxRows - sh.getMaxRows());
  }

  sh.getRange("B:B").setNumberFormat("yyyy-mm-dd");
  sh.getRange("E:G").setNumberFormat("0.00");
  sh.getRange("J:J").setNumberFormat("yyyy-mm-dd hh:mm:ss");

  const statusRule = SpreadsheetApp.newDataValidation()
    .requireValueInList(["Draft", "Ordered", "Received", "Cancelled"], true)
    .setAllowInvalid(false)
    .build();

  sh.getRange(2, 9, sh.getMaxRows() - 1, 1).setDataValidation(statusRule);

  SpreadsheetApp.getUi().alert("Purchase_Orders sheet fixed successfully.");
}

function pcCreatePurchaseOrder(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName("Purchase_Orders");
  if (!sh) throw new Error("Purchase_Orders sheet not found. Run pcFixPurchaseOrdersSheet() first.");

  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
  const rowObj = {};

  const poId = "PO-" + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyyMMdd-HHmmss");

  rowObj["PO_ID"] = poId;
  rowObj["PO_Date"] = data.poDate || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd");
  rowObj["Product_ID"] = String(data.productId || "").trim();
  rowObj["Product_Name"] = String(data.productName || "").trim();
  rowObj["Quantity"] = Number(data.quantity || 0);
  rowObj["Unit_Cost"] = Number(data.unitCost || 0);
  rowObj["Total_Cost"] = rowObj["Quantity"] * rowObj["Unit_Cost"];
  rowObj["Supplier"] = String(data.supplier || "").trim();
  rowObj["Status"] = String(data.status || "Draft").trim();
  rowObj["Created_At"] = new Date();

  const row = headers.map(h => rowObj[h] !== undefined ? rowObj[h] : "");
  sh.appendRow(row);

  return {
    success: true,
    poId: poId,
    message: "Purchase order created successfully"
  };
}
function pcTestCreatePurchaseOrder() {
  const result = pcCreatePurchaseOrder({
    productId: "P001",
    productName: "Vacutainer Tube",
    quantity: 100,
    unitCost: 12.5,
    supplier: "Sri Balaji Surgicals",
    status: "Draft"
  });

  Logger.log(result);
}

function pcShowCurrentWebRoutes() {
  Logger.log("PrimeCare active routes:");
  Logger.log("?page=agent -> PrimeCare_Agent_Updates");
  Logger.log("?page=stock -> PrimeCare_Stock_Dashboard");
  Logger.log("Only one active doGet(e) should exist in project.");
}

function pcwebGetDashboardSummary_() {
  const stock = pcwebGetStockDashboardData();
  const visitsSheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Agent_Visit_Log");

  let recentVisits = 0;
  let totalSoldValue = 0;

  if (visitsSheet && visitsSheet.getLastRow() > 1) {
    const values = visitsSheet.getDataRange().getValues();
    const headers = values[0].map(function(h) { return String(h).trim(); });
    const rows = values.slice(1);

    const soldIdx = headers.indexOf("Sold_Value");

    recentVisits = rows.filter(function(r) {
      return r.some(function(c) { return c !== ""; });
    }).length;

    if (soldIdx !== -1) {
      totalSoldValue = rows.reduce(function(sum, r) {
        return sum + Number(r[soldIdx] || 0);
      }, 0);
    }
  }

  return {
    stockStats: stock.stats || {},
    recentVisits: recentVisits,
    totalSoldValue: totalSoldValue
  };
}
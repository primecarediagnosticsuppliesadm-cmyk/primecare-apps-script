import React, { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, ClipboardCheck, IndianRupee, Activity, PhoneCall } from "lucide-react";
import { getCollections } from "@/api/primecareApi";
import { filterCollectionsForUser } from "@/utils/accessFilters";

function QuickStat({ title, value, icon: Icon }) {
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-slate-500">{title}</div>
          <div className="mt-1 text-xl font-semibold text-slate-900">{value}</div>
        </div>
        <div className="rounded-xl bg-slate-50 p-2">
          <Icon className="h-4 w-4 text-slate-700" />
        </div>
      </div>
    </div>
  );
}

function severityVariant(risk) {
  const value = String(risk || "").toLowerCase();
  if (value.includes("high")) return "destructive";
  if (value.includes("medium")) return "secondary";
  return "outline";
}

export default function CollectionsPage({ currentUser }) {
  const [summary, setSummary] = useState(null);
  const [collections, setCollections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  useEffect(() => {
    async function loadCollections() {
      try {
        const res = await getCollections();
        if (!res.success) throw new Error(res.error || "Failed to load collections");

        setSummary(res.data?.summary || {});
        setCollections(res.data?.collections || []);
      } catch (err) {
        setError(err.message || "Failed to load collections");
      } finally {
        setLoading(false);
      }
    }

    loadCollections();
  }, []);

  const visibleCollections = useMemo(() => {
    return filterCollectionsForUser(collections, currentUser);
  }, [collections, currentUser]);

  const visibleSummary = useMemo(() => {
    return {
      totalOutstanding: visibleCollections.reduce((sum, x) => sum + Number(x.outstandingAmount || 0), 0),
      overdueCount: visibleCollections.filter((x) => Number(x.overdueDays || 0) > 0).length,
      highRiskCount: visibleCollections.filter((x) => String(x.riskStatus || "").toLowerCase().includes("high")).length,
      todayCollections: 0,
    };
  }, [visibleCollections]);

  function markFollowedUp(labName) {
    setStatusMessage(`Follow-up noted for ${labName}`);
  }

  if (loading) return <div className="p-4 text-slate-600">Loading collections...</div>;
  if (error) return <div className="p-4 text-red-600">{error}</div>;

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">Collections</h1>
        <p className="text-sm text-slate-500">
          {currentUser?.role === "agent"
            ? "Assigned collection follow-ups optimized for fast mobile action."
            : "Collections and credit-risk overview."}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <QuickStat
          title="Outstanding"
          value={`₹${Number(visibleSummary.totalOutstanding || 0).toLocaleString()}`}
          icon={IndianRupee}
        />
        <QuickStat
          title="Overdue Labs"
          value={visibleSummary.overdueCount || 0}
          icon={ClipboardCheck}
        />
        <QuickStat
          title="High Risk"
          value={visibleSummary.highRiskCount || 0}
          icon={AlertTriangle}
        />
        <QuickStat
          title="Today Collections"
          value={`₹${Number(visibleSummary.todayCollections || 0).toLocaleString()}`}
          icon={Activity}
        />
      </div>

      {statusMessage ? (
        <div className="rounded-xl bg-green-50 p-3 text-sm text-green-700">
          {statusMessage}
        </div>
      ) : null}

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Collection Tasks</CardTitle>
          <CardDescription>
            Tap-friendly collection cards for fast field follow-up.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <div className="space-y-3">
            {visibleCollections.length === 0 ? (
              <div className="text-sm text-slate-500">No collection records found.</div>
            ) : (
              visibleCollections.map((item, idx) => (
                <div
                  key={`${item.labName}-${idx}`}
                  className="rounded-2xl border bg-white p-4 shadow-sm"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <div className="text-base font-semibold text-slate-900">
                        {item.labName || "-"}
                      </div>
                      <div className="mt-1 text-sm text-slate-500">
                        Agent: {item.assignedAgent || "-"} • Area: {item.area || "-"}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">
                        ₹{Number(item.outstandingAmount || 0).toLocaleString()}
                      </Badge>
                      <Badge variant={severityVariant(item.riskStatus)}>
                        {item.riskStatus || "Low"}
                      </Badge>
                    </div>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-3 text-sm text-slate-600">
                    <div>
                      <span className="font-medium">Overdue:</span> {Number(item.overdueDays || 0)} days
                    </div>
                    <div>
                      <span className="font-medium">Status:</span> {item.paymentStatus || "Pending"}
                    </div>
                  </div>

                  <div className="mt-2 text-sm text-slate-600">
                    <span className="font-medium">Next Action:</span> {item.nextAction || "-"}
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      className="h-11 rounded-xl"
                      onClick={() => markFollowedUp(item.labName)}
                    >
                      <PhoneCall className="mr-2 h-4 w-4" />
                      Followed Up
                    </Button>

                    <Button
                      type="button"
                      className="h-11 rounded-xl"
                      onClick={() => markFollowedUp(item.labName)}
                    >
                      <ClipboardCheck className="mr-2 h-4 w-4" />
                      Mark Updated
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
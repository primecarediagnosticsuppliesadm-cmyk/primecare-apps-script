import React, { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ShoppingCart, RotateCcw, FileText, IndianRupee, Package } from "lucide-react";

function QuickStat({ title, value, icon: Icon }) {
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-slate-500">{title}</div>
          <div className="mt-1 text-xl font-semibold text-slate-900">{value}</div>
        </div>
        <div className="rounded-xl bg-slate-50 p-2">
          <Icon className="h-4 w-4 text-slate-700" />
        </div>
      </div>
    </div>
  );
}

const demoCatalog = [
  { productId: "P001", productName: "Vacutainer Red", category: "Vacutainers", price: 650, quickOrder: true },
  { productId: "P002", productName: "Vacutainer Purple", category: "Vacutainers", price: 720, quickOrder: true },
  { productId: "P003", productName: "CBC Reagent Kit", category: "Reagents", price: 5400, quickOrder: true },
  { productId: "P004", productName: "Pipette Tips 200µL", category: "Consumables", price: 980, quickOrder: false },
];

const demoRecentOrders = [
  { orderId: "ORD-20260314-0002", date: "2026-03-14", status: "Delivered", total: 12500 },
  { orderId: "ORD-20260310-0001", date: "2026-03-10", status: "In Transit", total: 8400 },
  { orderId: "ORD-20260305-0007", date: "2026-03-05", status: "Delivered", total: 16200 },
];

export default function LabOrderingPage({ currentUser }) {
  const [search, setSearch] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  const visibleCatalog = useMemo(() => {
    return demoCatalog.filter((item) =>
      `${item.productName} ${item.category} ${item.productId}`
        .toLowerCase()
        .includes(search.toLowerCase())
    );
  }, [search]);

  const quickOrderItems = useMemo(
    () => visibleCatalog.filter((item) => item.quickOrder),
    [visibleCatalog]
  );

  const outstandingBalance = 18500;

  function addToOrder(productName) {
    setStatusMessage(`${productName} added to order queue`);
  }

  function quickReorder(productName) {
    setStatusMessage(`Quick reorder started for ${productName}`);
  }

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">Lab Ordering</h1>
        <p className="text-sm text-slate-500">
          Welcome {currentUser?.name || "Lab"} — fast mobile ordering for repeat purchases.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <QuickStat
          title="Outstanding"
          value={`₹${Number(outstandingBalance).toLocaleString()}`}
          icon={IndianRupee}
        />
        <QuickStat
          title="Recent Orders"
          value={demoRecentOrders.length}
          icon={FileText}
        />
        <QuickStat
          title="Quick Reorder"
          value={quickOrderItems.length}
          icon={RotateCcw}
        />
        <QuickStat
          title="Catalog"
          value={visibleCatalog.length}
          icon={Package}
        />
      </div>

      {statusMessage ? (
        <div className="rounded-xl bg-green-50 p-3 text-sm text-green-700">
          {statusMessage}
        </div>
      ) : null}

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Search Catalog</CardTitle>
          <CardDescription>Find products quickly and place orders on mobile.</CardDescription>
        </CardHeader>
        <CardContent>
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-12 rounded-xl text-base"
          />
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Quick Order Catalog</CardTitle>
          <CardDescription>Tap-friendly ordering for frequently used items.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {visibleCatalog.length === 0 ? (
              <div className="text-sm text-slate-500">No products found.</div>
            ) : (
              visibleCatalog.map((item) => (
                <div
                  key={item.productId}
                  className="rounded-2xl border bg-white p-4 shadow-sm"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <div className="text-base font-semibold text-slate-900">
                        {item.productName}
                      </div>
                      <div className="mt-1 text-sm text-slate-500">
                        {item.category} • {item.productId}
                      </div>
                    </div>

                    <Badge variant="secondary">
                      ₹{Number(item.price).toLocaleString()}
                    </Badge>
                  </div>

                  <div className="mt-4">
                    <Button
                      className="h-11 w-full rounded-xl"
                      onClick={() => addToOrder(item.productName)}
                    >
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Add to Order
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Quick Reorder</CardTitle>
          <CardDescription>Fast repeat ordering for common products.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {quickOrderItems.map((item) => (
              <div key={item.productId} className="rounded-2xl border bg-white p-4 shadow-sm">
                <div className="text-base font-semibold text-slate-900">{item.productName}</div>
                <div className="mt-1 text-sm text-slate-500">
                  ₹{Number(item.price).toLocaleString()}
                </div>
                <Button
                  className="mt-4 h-11 w-full rounded-xl"
                  variant="outline"
                  onClick={() => quickReorder(item.productName)}
                >
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Quick Reorder
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Recent Orders</CardTitle>
          <CardDescription>Your latest visible orders.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {demoRecentOrders.map((order) => (
              <div
                key={order.orderId}
                className="rounded-2xl border bg-white p-4 shadow-sm"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <div className="text-base font-semibold text-slate-900">{order.orderId}</div>
                    <div className="mt-1 text-sm text-slate-500">
                      Date: {order.date}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">{order.status}</Badge>
                    <Badge>₹{Number(order.total).toLocaleString()}</Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
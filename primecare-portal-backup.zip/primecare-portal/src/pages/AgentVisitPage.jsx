import React, { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ClipboardCheck, MapPin, PlusCircle, Users } from "lucide-react";

import { getLabs, getRecentVisits, saveAgentVisit } from "@/api/primecareApi";
import { filterLabsForUser, filterVisitsForUser } from "@/utils/accessFilters";

function QuickStat({ title, value, icon: Icon }) {
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-slate-500">{title}</div>
          <div className="mt-1 text-xl font-semibold text-slate-900">{value}</div>
        </div>
        <div className="rounded-xl bg-slate-50 p-2">
          <Icon className="h-4 w-4 text-slate-700" />
        </div>
      </div>
    </div>
  );
}

function normalizeLab(lab) {
  return {
    labId: lab.labId || lab.Lab_ID || "",
    labName: lab.labName || lab.Lab_Name || lab.name || "",
    area: lab.area || lab.Area || "",
    assignedAgent:
      lab.assignedAgent ||
      lab.agentName ||
      lab.Agent_Name ||
      lab.owner ||
      "",
    status: lab.status || lab.Status || "Active",
    nextFollowUp: lab.nextFollowUp || lab.Next_Follow_Up || "-",
  };
}

function normalizeVisit(v) {
  return {
    id: v.id || v.Visit_ID || "",
    agent: v.agent || v.agentName || v.Agent_Name || "",
    date: v.date || v.visitDate || v.Visit_Date || "",
    labName: v.labName || v.Lab_Name || "",
    area: v.area || v.Area || "",
    visitType: v.visitType || v.Visit_Type || "",
    labResponse: v.labResponse || v.Lab_Response || "",
    soldValue: Number(v.soldValue || v.Sold_Value || 0),
  };
}

export default function AgentVisitPage({ currentUser }) {
  const [labs, setLabs] = useState([]);
  const [recentVisits, setRecentVisits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [statusType, setStatusType] = useState("success");

  const [form, setForm] = useState({
    agentName: currentUser?.agentName || currentUser?.name || "",
    visitDate: new Date().toISOString().slice(0, 10),
    labId: "",
    labName: "",
    area: currentUser?.assignedArea || "",
    visitType: "Follow-up",
    samplesGiven: "",
    demoGiven: "No",
    labResponse: "Warm",
    soldValue: "",
    stockAvailable: "Yes",
    needsNewStock: "No",
    nextAction: "",
    notes: "",
  });

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [labsRes, visitsRes] = await Promise.all([
          getLabs(),
          getRecentVisits(),
        ]);

        if (!labsRes.success) throw new Error(labsRes.error || "Failed to load labs");
        if (!visitsRes.success) throw new Error(visitsRes.error || "Failed to load visits");

        const normalizedLabs = (labsRes.data?.labs || []).map(normalizeLab);
        const normalizedVisits = (visitsRes.data?.visits || []).map(normalizeVisit);

        setLabs(normalizedLabs);
        setRecentVisits(normalizedVisits);
      } catch (err) {
        setStatusMessage(err.message || "Failed to load agent visit page");
        setStatusType("error");
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  useEffect(() => {
    setForm((prev) => ({
      ...prev,
      agentName: currentUser?.agentName || currentUser?.name || prev.agentName,
    }));
  }, [currentUser]);

  const visibleLabs = useMemo(() => {
    return filterLabsForUser(labs, currentUser);
  }, [labs, currentUser]);

  const visibleVisits = useMemo(() => {
    return filterVisitsForUser(recentVisits, currentUser);
  }, [recentVisits, currentUser]);

  const todayVisits = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return visibleVisits.filter((v) => String(v.date).slice(0, 10) === today).length;
  }, [visibleVisits]);

  const pendingFollowUps = useMemo(() => {
    return visibleLabs.filter((lab) => lab.nextFollowUp && lab.nextFollowUp !== "-").length;
  }, [visibleLabs]);

  function handleLabChange(value) {
    const selected = visibleLabs.find((lab) => lab.labId === value);
    setForm((prev) => ({
      ...prev,
      labId: selected?.labId || "",
      labName: selected?.labName || "",
      area: selected?.area || prev.area,
    }));
  }

  async function handleSaveVisit() {
    if (!form.agentName || !form.labName || !form.visitDate || !form.visitType) {
      setStatusMessage("Please fill agent, lab, date, and visit type.");
      setStatusType("error");
      return;
    }

    try {
      setSaving(true);
      setStatusMessage("");

      const payload = {
        visitDate: form.visitDate,
        agentName: form.agentName,
        labId: form.labId,
        labName: form.labName,
        area: form.area,
        visitType: form.visitType,
        samplesGiven: Number(form.samplesGiven || 0),
        demoGiven: form.demoGiven,
        labResponse: form.labResponse,
        soldValue: Number(form.soldValue || 0),
        stockAvailable: form.stockAvailable,
        needsNewStock: form.needsNewStock,
        nextAction: form.nextAction,
        notes: form.notes,
      };

      const res = await saveAgentVisit(payload);
      if (!res.success) throw new Error(res.error || "Failed to save visit");

      const newVisit = normalizeVisit({
        id: res.data?.visitId || `VISIT-${Date.now()}`,
        agent: form.agentName,
        date: form.visitDate,
        labName: form.labName,
        area: form.area,
        visitType: form.visitType,
        labResponse: form.labResponse,
        soldValue: form.soldValue,
      });

      setRecentVisits((prev) => [newVisit, ...prev]);

      setStatusMessage(`Visit saved successfully${res.data?.visitId ? `: ${res.data.visitId}` : ""}`);
      setStatusType("success");

      setForm((prev) => ({
        ...prev,
        visitDate: new Date().toISOString().slice(0, 10),
        labId: "",
        labName: "",
        area: currentUser?.assignedArea || "",
        visitType: "Follow-up",
        samplesGiven: "",
        demoGiven: "No",
        labResponse: "Warm",
        soldValue: "",
        stockAvailable: "Yes",
        needsNewStock: "No",
        nextAction: "",
        notes: "",
      }));
    } catch (err) {
      setStatusMessage(err.message || "Failed to save visit");
      setStatusType("error");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div className="p-4 text-slate-600">Loading visit page...</div>;
  }

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">Agent Visits</h1>
        <p className="text-sm text-slate-500">
          Fast mobile visit logging for field work.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <QuickStat title="My Labs" value={visibleLabs.length} icon={Users} />
        <QuickStat title="Today Visits" value={todayVisits} icon={ClipboardCheck} />
        <QuickStat title="Follow-ups" value={pendingFollowUps} icon={MapPin} />
        <QuickStat title="Recent Visits" value={visibleVisits.length} icon={Users} />
      </div>

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Log Field Visit</CardTitle>
          <CardDescription>
            Large tap targets and single-column layout for quick mobile use.
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input
              value={form.agentName}
              onChange={(e) => setForm({ ...form, agentName: e.target.value })}
              placeholder="Agent name"
              className="h-12 rounded-xl text-base"
              disabled={currentUser?.role === "agent"}
            />

            <Input
              type="date"
              value={form.visitDate}
              onChange={(e) => setForm({ ...form, visitDate: e.target.value })}
              className="h-12 rounded-xl text-base"
            />

            <div className="md:col-span-2">
              <Select value={form.labId} onValueChange={handleLabChange}>
                <SelectTrigger className="h-12 rounded-xl text-base">
                  <SelectValue placeholder="Select lab" />
                </SelectTrigger>
                <SelectContent>
                  {visibleLabs.map((lab) => (
                    <SelectItem key={lab.labId} value={lab.labId}>
                      {lab.labName} ({lab.labId || "No ID"})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Input
              value={form.labName}
              onChange={(e) => setForm({ ...form, labName: e.target.value })}
              placeholder="Lab name"
              className="h-12 rounded-xl text-base"
            />

            <Input
              value={form.area}
              onChange={(e) => setForm({ ...form, area: e.target.value })}
              placeholder="Area"
              className="h-12 rounded-xl text-base"
            />

            <Select value={form.visitType} onValueChange={(value) => setForm({ ...form, visitType: value })}>
              <SelectTrigger className="h-12 rounded-xl text-base">
                <SelectValue placeholder="Visit type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="New Lead">New Lead</SelectItem>
                <SelectItem value="Follow-up">Follow-up</SelectItem>
                <SelectItem value="Closing">Closing</SelectItem>
                <SelectItem value="Collection">Collection</SelectItem>
                <SelectItem value="Support Visit">Support Visit</SelectItem>
              </SelectContent>
            </Select>

            <Input
              value={form.samplesGiven}
              onChange={(e) => setForm({ ...form, samplesGiven: e.target.value })}
              placeholder="Samples given"
              className="h-12 rounded-xl text-base"
            />

            <Select value={form.demoGiven} onValueChange={(value) => setForm({ ...form, demoGiven: value })}>
              <SelectTrigger className="h-12 rounded-xl text-base">
                <SelectValue placeholder="Demo given" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Yes">Yes</SelectItem>
                <SelectItem value="No">No</SelectItem>
              </SelectContent>
            </Select>

            <Select value={form.labResponse} onValueChange={(value) => setForm({ ...form, labResponse: value })}>
              <SelectTrigger className="h-12 rounded-xl text-base">
                <SelectValue placeholder="Lab response" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Interested">Interested</SelectItem>
                <SelectItem value="Warm">Warm</SelectItem>
                <SelectItem value="Not Interested">Not Interested</SelectItem>
                <SelectItem value="Converted">Converted</SelectItem>
                <SelectItem value="Need Follow-up">Need Follow-up</SelectItem>
              </SelectContent>
            </Select>

            <Input
              value={form.soldValue}
              onChange={(e) => setForm({ ...form, soldValue: e.target.value })}
              placeholder="Sold value"
              className="h-12 rounded-xl text-base"
            />

            <Select
              value={form.stockAvailable}
              onValueChange={(value) => setForm({ ...form, stockAvailable: value })}
            >
              <SelectTrigger className="h-12 rounded-xl text-base">
                <SelectValue placeholder="Stock available" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Yes">Yes</SelectItem>
                <SelectItem value="No">No</SelectItem>
                <SelectItem value="Partial">Partial</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={form.needsNewStock}
              onValueChange={(value) => setForm({ ...form, needsNewStock: value })}
            >
              <SelectTrigger className="h-12 rounded-xl text-base">
                <SelectValue placeholder="Needs new stock" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Yes">Yes</SelectItem>
                <SelectItem value="No">No</SelectItem>
              </SelectContent>
            </Select>

            <div className="md:col-span-2">
              <Input
                value={form.nextAction}
                onChange={(e) => setForm({ ...form, nextAction: e.target.value })}
                placeholder="Next action"
                className="h-12 rounded-xl text-base"
              />
            </div>

            <div className="md:col-span-2">
              <Textarea
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                placeholder="Notes"
                className="min-h-[110px] rounded-xl text-base"
              />
            </div>
          </div>

          {statusMessage ? (
            <div
              className={`rounded-xl p-3 text-sm ${
                statusType === "error"
                  ? "bg-red-50 text-red-700"
                  : "bg-green-50 text-green-700"
              }`}
            >
              {statusMessage}
            </div>
          ) : null}

          <div className="sticky bottom-3 z-10 bg-white/90 pt-2 backdrop-blur">
            <Button
              onClick={handleSaveVisit}
              disabled={saving}
              className="h-12 w-full rounded-xl text-base"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              {saving ? "Saving..." : "Save Visit"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Recent Visible Visits</CardTitle>
          <CardDescription>
            Latest visit records visible to this agent.
          </CardDescription>
        </CardHeader>

        <CardContent>
          <div className="space-y-3">
            {visibleVisits.length === 0 ? (
              <div className="text-sm text-slate-500">No recent visits found.</div>
            ) : (
              visibleVisits.slice(0, 6).map((visit, idx) => (
                <div
                  key={`${visit.id || visit.labName}-${idx}`}
                  className="rounded-2xl border p-4"
                >
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="font-semibold text-slate-900">{visit.labName || "-"}</div>
                      <div className="text-sm text-slate-500">
                        {visit.area || "-"} • {visit.date || "-"}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Badge>{visit.visitType || "-"}</Badge>
                      <Badge variant="secondary">{visit.labResponse || "-"}</Badge>
                    </div>
                  </div>

                  <div className="mt-3 text-sm text-slate-600">
                    Sold value: ₹{Number(visit.soldValue || 0).toLocaleString()}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
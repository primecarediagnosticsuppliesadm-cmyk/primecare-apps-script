import React, { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ClipboardCheck,
  Wallet,
  Building2,
  MapPin,
  PlusCircle,
  PhoneCall,
} from "lucide-react";

import { getLabs, getRecentVisits, getCollections } from "@/api/primecareApi";
import {
  filterLabsForUser,
  filterVisitsForUser,
  filterCollectionsForUser,
} from "@/utils/accessFilters";

function QuickStat({ title, value, icon: Icon }) {
  return (
    <div className="rounded-2xl border bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs text-slate-500">{title}</div>
          <div className="mt-1 text-xl font-semibold text-slate-900">{value}</div>
        </div>
        <div className="rounded-xl bg-slate-50 p-2">
          <Icon className="h-4 w-4 text-slate-700" />
        </div>
      </div>
    </div>
  );
}

function normalizeLab(lab) {
  return {
    labId: lab.labId || lab.Lab_ID || "",
    labName: lab.labName || lab.Lab_Name || lab.name || "",
    area: lab.area || lab.Area || "",
    assignedAgent:
      lab.assignedAgent ||
      lab.agentName ||
      lab.Agent_Name ||
      lab.owner ||
      "",
    nextFollowUp: lab.nextFollowUp || lab.Next_Follow_Up || "-",
  };
}

function normalizeVisit(v) {
  return {
    id: v.id || v.Visit_ID || "",
    agent: v.agent || v.agentName || v.Agent_Name || "",
    date: v.date || v.visitDate || v.Visit_Date || "",
    labName: v.labName || v.Lab_Name || "",
    area: v.area || v.Area || "",
    visitType: v.visitType || v.Visit_Type || "",
    labResponse: v.labResponse || v.Lab_Response || "",
  };
}

function normalizeCollection(c) {
  return {
    labName: c.labName || c.Lab_Name || "",
    assignedAgent: c.assignedAgent || c.agentName || c.Agent_Name || "",
    outstandingAmount: Number(c.outstandingAmount || c.Amount_Due || 0),
    overdueDays: Number(c.overdueDays || c.Overdue_Days || 0),
    riskStatus: c.riskStatus || c.Risk_Status || "Low",
    nextAction: c.nextAction || c.Next_Action || "-",
  };
}

export default function AgentDashboard({ currentUser, setActivePage }) {
  const [labs, setLabs] = useState([]);
  const [visits, setVisits] = useState([]);
  const [collections, setCollections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        setError("");

        const [labsRes, visitsRes, collectionsRes] = await Promise.all([
          getLabs(),
          getRecentVisits(),
          getCollections(),
        ]);

        if (!labsRes.success) throw new Error(labsRes.error || "Failed to load labs");
        if (!visitsRes.success) throw new Error(visitsRes.error || "Failed to load visits");
        if (!collectionsRes.success) throw new Error(collectionsRes.error || "Failed to load collections");

        setLabs((labsRes.data?.labs || []).map(normalizeLab));
        setVisits((visitsRes.data?.visits || []).map(normalizeVisit));
        setCollections((collectionsRes.data?.collections || []).map(normalizeCollection));
      } catch (err) {
        setError(err.message || "Failed to load agent dashboard");
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  const visibleLabs = useMemo(() => filterLabsForUser(labs, currentUser), [labs, currentUser]);
  const visibleVisits = useMemo(() => filterVisitsForUser(visits, currentUser), [visits, currentUser]);
  const visibleCollections = useMemo(
    () => filterCollectionsForUser(collections, currentUser),
    [collections, currentUser]
  );

  const today = new Date().toISOString().slice(0, 10);

  const todayVisits = useMemo(
    () => visibleVisits.filter((v) => String(v.date).slice(0, 10) === today).length,
    [visibleVisits, today]
  );

  const pendingCollections = useMemo(
    () => visibleCollections.filter((c) => Number(c.outstandingAmount || 0) > 0).length,
    [visibleCollections]
  );

  const followUpsDue = useMemo(
    () => visibleLabs.filter((lab) => lab.nextFollowUp && lab.nextFollowUp !== "-").length,
    [visibleLabs]
  );

  const topCollectionTasks = useMemo(() => {
    return [...visibleCollections]
      .sort((a, b) => Number(b.outstandingAmount || 0) - Number(a.outstandingAmount || 0))
      .slice(0, 3);
  }, [visibleCollections]);

  const recentActivity = useMemo(() => visibleVisits.slice(0, 4), [visibleVisits]);

  if (loading) {
    return <div className="p-4 text-slate-600">Loading agent dashboard...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-600">{error}</div>;
  }

  return (
    <div className="space-y-5">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">
          Welcome, {currentUser?.name || "Agent"}
        </h1>
        <p className="text-sm text-slate-500">
          Your field summary for today.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <QuickStat title="Today Visits" value={todayVisits} icon={ClipboardCheck} />
        <QuickStat title="Collections" value={pendingCollections} icon={Wallet} />
        <QuickStat title="My Labs" value={visibleLabs.length} icon={Building2} />
        <QuickStat title="Follow-ups" value={followUpsDue} icon={MapPin} />
      </div>

      <Card className="rounded-2xl shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Quick Actions</CardTitle>
          <CardDescription>Fast actions for field work</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-3">
          <Button
            className="h-12 rounded-xl"
            onClick={() => setActivePage?.("visits")}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Visit
          </Button>

          <Button
            variant="outline"
            className="h-12 rounded-xl"
            onClick={() => setActivePage?.("collections")}
          >
            <PhoneCall className="mr-2 h-4 w-4" />
            Collections
          </Button>

          <Button
            variant="outline"
            className="h-12 rounded-xl"
            onClick={() => setActivePage?.("labs")}
          >
            <Building2 className="mr-2 h-4 w-4" />
            My Labs
          </Button>

          <Button
            variant="outline"
            className="h-12 rounded-xl"
            onClick={() => setActivePage?.("visits")}
          >
            <ClipboardCheck className="mr-2 h-4 w-4" />
            Log Update
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="rounded-2xl shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Priority Collections</CardTitle>
            <CardDescription>Top collection tasks by amount due</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topCollectionTasks.length === 0 ? (
                <div className="text-sm text-slate-500">No pending collection tasks.</div>
              ) : (
                topCollectionTasks.map((item, idx) => (
                  <div key={`${item.labName}-${idx}`} className="rounded-2xl border p-4">
                    <div className="font-semibold text-slate-900">{item.labName || "-"}</div>
                    <div className="mt-1 text-sm text-slate-500">
                      ₹{Number(item.outstandingAmount || 0).toLocaleString()} • Overdue {Number(item.overdueDays || 0)}d
                    </div>
                    <div className="mt-2">
                      <Badge variant="secondary">{item.riskStatus || "Low"}</Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Recent Activity</CardTitle>
            <CardDescription>Your latest visible visit activity</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentActivity.length === 0 ? (
                <div className="text-sm text-slate-500">No recent visits found.</div>
              ) : (
                recentActivity.map((visit, idx) => (
                  <div key={`${visit.id || visit.labName}-${idx}`} className="rounded-2xl border p-4">
                    <div className="font-semibold text-slate-900">{visit.labName || "-"}</div>
                    <div className="mt-1 text-sm text-slate-500">
                      {visit.area || "-"} • {visit.date || "-"}
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Badge>{visit.visitType || "-"}</Badge>
                      <Badge variant="secondary">{visit.labResponse || "-"}</Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
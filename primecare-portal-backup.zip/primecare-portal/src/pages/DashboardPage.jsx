import { useEffect, useState } from "react";
import { getDashboard } from "../api/primecareApi";

export default function DashboardPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadDashboard() {
      try {
        const res = await getDashboard();

        if (!res.success) {
          throw new Error(res.error || "Failed to load dashboard");
        }

        setData(res.data || {});
      } catch (err) {
        setError(err.message || "Something went wrong");
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, []);

  if (loading) {
    return <h2 style={{ padding: "20px" }}>Loading dashboard...</h2>;
  }

  if (error) {
    return <h2 style={{ padding: "20px", color: "red" }}>{error}</h2>;
  }

  const stockStats = data?.stockStats || {};

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>PrimeCare Dashboard</h1>

      <div style={styles.grid}>
        <div style={styles.card}>
          <div style={styles.label}>Total SKUs</div>
          <div style={styles.value}>{stockStats.totalSkus || 0}</div>
        </div>

        <div style={styles.card}>
          <div style={styles.label}>Critical Items</div>
          <div style={styles.value}>{stockStats.criticalItems || 0}</div>
        </div>

        <div style={styles.card}>
          <div style={styles.label}>Reorder Items</div>
          <div style={styles.value}>{stockStats.reorderItems || 0}</div>
        </div>

        <div style={styles.card}>
          <div style={styles.label}>Healthy Items</div>
          <div style={styles.value}>{stockStats.healthyItems || 0}</div>
        </div>

        <div style={styles.card}>
          <div style={styles.label}>Recent Visits</div>
          <div style={styles.value}>{data?.recentVisits || 0}</div>
        </div>

        <div style={styles.card}>
          <div style={styles.label}>Total Sold Value</div>
          <div style={styles.value}>{data?.totalSoldValue || 0}</div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    padding: "20px",
    fontFamily: "Arial, sans-serif",
    background: "#f8fafc",
    minHeight: "100vh",
  },
  title: {
    marginBottom: "20px",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
    gap: "16px",
  },
  card: {
    background: "white",
    border: "1px solid #e2e8f0",
    borderRadius: "14px",
    padding: "16px",
    boxShadow: "0 1px 4px rgba(0,0,0,0.04)",
  },
  label: {
    fontSize: "13px",
    color: "#64748b",
    marginBottom: "8px",
  },
  value: {
    fontSize: "28px",
    fontWeight: "700",
    color: "#0f172a",
  },
};
import React, { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, Users, MapPin, ClipboardCheck } from "lucide-react";
import { getLabs } from "@/api/primecareApi";
import { filterLabsForUser } from "@/utils/accessFilters";

function StatCard({ title, value, icon: Icon, subtitle }) {
  return (
    <Card className="rounded-2xl shadow-sm border-slate-200">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm text-slate-500">{title}</p>
            <h3 className="text-2xl font-bold mt-1 text-slate-900">{value}</h3>
            <p className="text-xs text-slate-500 mt-1">{subtitle}</p>
          </div>
          <div className="rounded-2xl p-3 bg-slate-50">
            <Icon className="w-5 h-5 text-slate-700" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function normalizeLab(lab) {
  return {
    labId: lab.labId || lab.Lab_ID || "",
    labName: lab.labName || lab.Lab_Name || lab.name || "",
    area: lab.area || lab.Area || "",
    assignedAgent:
      lab.assignedAgent ||
      lab.agentName ||
      lab.Agent_Name ||
      lab.owner ||
      "",
    status: lab.status || lab.Status || "Active",
    stage: lab.stage || lab.Stage || "Existing",
    lastVisit: lab.lastVisit || lab.Last_Visit || "-",
    nextFollowUp: lab.nextFollowUp || lab.Next_Follow_Up || "-",
  };
}

export default function LabsPage({ currentUser }) {
  const [labs, setLabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadLabs() {
      try {
        const res = await getLabs();
        if (!res.success) throw new Error(res.error || "Failed to load labs");

        const rows = (res.data?.labs || []).map(normalizeLab);
        setLabs(rows);
      } catch (err) {
        setError(err.message || "Failed to load labs");
      } finally {
        setLoading(false);
      }
    }

    loadLabs();
  }, []);

  const visibleLabs = useMemo(() => {
    return filterLabsForUser(labs, currentUser);
  }, [labs, currentUser]);

  const metrics = useMemo(() => {
    return {
      total: visibleLabs.length,
      active: visibleLabs.filter((x) => String(x.status).toLowerCase() === "active").length,
      assigned: visibleLabs.filter((x) => x.assignedAgent).length,
      followUps: visibleLabs.filter((x) => x.nextFollowUp && x.nextFollowUp !== "-").length,
    };
  }, [visibleLabs]);

  if (loading) {
    return <div className="p-4 text-slate-600">Loading labs...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-600">{error}</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Labs</h1>
        <p className="text-sm text-muted-foreground">
          {currentUser?.role === "agent"
            ? "Only labs assigned to this logged-in agent are visible."
            : "Lab master, assignments, and follow-up visibility."}
        </p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <StatCard
          title="Visible Labs"
          value={metrics.total}
          icon={Building2}
          subtitle="Labs visible to this user"
        />
        <StatCard
          title="Active Labs"
          value={metrics.active}
          icon={ClipboardCheck}
          subtitle="Currently active accounts"
        />
        <StatCard
          title="Assigned"
          value={metrics.assigned}
          icon={Users}
          subtitle="Labs with assigned agent"
        />
        <StatCard
          title="Follow-ups"
          value={metrics.followUps}
          icon={MapPin}
          subtitle="Pending follow-up actions"
        />
      </div>

      <Card className="rounded-2xl shadow-sm">
        <CardHeader>
          <CardTitle>Lab Directory</CardTitle>
          <CardDescription>
            Territory, assignment, and follow-up visibility
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {visibleLabs.length === 0 ? (
              <div className="text-sm text-slate-500">No labs found for this user.</div>
            ) : (
              visibleLabs.map((lab, idx) => (
                <div
                  key={`${lab.labId || lab.labName}-${idx}`}
                  className="rounded-2xl border p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4"
                >
                  <div>
                    <div className="font-semibold text-slate-900">
                      {lab.labName || "Unnamed Lab"}
                    </div>
                    <div className="text-sm text-slate-500">
                      ID: {lab.labId || "-"} • Area: {lab.area || "-"}
                    </div>
                    <div className="text-sm text-slate-500 mt-1">
                      Assigned Agent: {lab.assignedAgent || "-"}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 items-center text-sm">
                    <Badge variant="secondary">{lab.status || "Active"}</Badge>
                    <Badge variant="secondary">Stage: {lab.stage || "Existing"}</Badge>
                    <Badge variant="outline">Last Visit: {lab.lastVisit || "-"}</Badge>
                    <Badge variant="outline">Next Follow-up: {lab.nextFollowUp || "-"}</Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
const API_BASE =
  "https://script.google.com/macros/s/AKfycbzBV1N2Ae3PZttnMcJ4YdUiljYf3cHPMrQo129kTDv0I57gNQwcHduCCXx58qJ_OKf43w/exec";

export async function getStock() {
  const res = await fetch(`${API_BASE}?action=getStock`);
  return res.json();
}

export async function getLabs() {
  const res = await fetch(`${API_BASE}?action=getLabs`);
  return res.json();
}

export async function getDashboard() {
  const res = await fetch(`${API_BASE}?action=getDashboard`);
  return res.json();
}

export async function getExecutiveSnapshot() {
  const res = await fetch(`${API_BASE}?action=getExecutiveSnapshot`);
  return res.json();
}

export async function getRecentVisits() {
  const res = await fetch(`${API_BASE}?action=getRecentVisits`);
  return res.json();
}

export async function saveAgentVisit(payload) {
  const res = await fetch("/api/save-visit", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  return res.json();
}
export async function getCollections() {
  const res = await fetch(`${API_BASE}?action=getCollections`);
  return res.json();
}
export async function getCurrentUser(){
  const res = await fetch(`${API_BASE}?action=getCurrentUser`);
  return res.json();
}
export async function getAIInsights() {
  const res = await fetch(`${API_BASE}?action=getAIInsights`);
  return res.json();
}
export async function getReorderForecast() {
  const res = await fetch(`${API_BASE}?action=getReorderForecast`);
  return res.json();
}
import { PERMISSIONS } from "./permissions";

export const MENU_ITEMS = [
  { key: "dashboard", label: "Dashboard" },
  { key: "visits", label: "Visits" },
  { key: "collections", label: "Collections" },
  { key: "labs", label: "Labs" },
  { key: "inventory", label: "Inventory" },
  { key: "orders", label: "Orders" },
  { key: "risk", label: "Credit & Risk" },
  { key: "performance", label: "Performance" },
  { key: "insights", label: "Insights / AI" },
  { key: "labOrders", label: "Lab Ordering" },
];

export function getMenuForRole(role) {
  return MENU_ITEMS.filter((item) => PERMISSIONS[item.key]?.includes(role));
}

export function getDefaultPageForRole(role) {
  const menu = getMenuForRole(role);
  return menu.length ? menu[0].key : null;
}
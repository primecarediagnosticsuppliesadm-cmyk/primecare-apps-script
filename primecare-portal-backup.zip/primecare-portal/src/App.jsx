import { useEffect, useMemo, useState } from "react";
import PortalLayout from "./layout/PortalLayout";
import PrimeCareWebPortal from "./PrimeCareWebPortal";
import { ROLES } from "./config/roles";
import { getDefaultPageForRole } from "./config/menuConfig";
import { getCurrentUser } from "./api/primecareApi";

function normalizeRole(role) {
  const value = String(role || "").trim().toLowerCase();

  if (value === "agent") return ROLES.AGENT;
  if (value === "admin") return ROLES.ADMIN;
  if (value === "executive") return ROLES.EXECUTIVE;
  if (value === "lab") return ROLES.LAB;

  return ROLES.EXECUTIVE;
}

export default function App() {
  const [role, setRole] = useState(null);
  const [activePage, setActivePage] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const [userError, setUserError] = useState("");

  useEffect(() => {
    async function loadUser() {
      try {
        setLoadingUser(true);
        setUserError("");

        const res = await getCurrentUser();
        console.log("getCurrentUser response:", res);

        if (!res.success) {
          throw new Error(res.error || "Failed to load current user");
        }

        const apiUser = res.data || {};
        const normalizedRole = normalizeRole(apiUser.role);

        const normalizedUser = {
          id: apiUser.id || apiUser.userId || apiUser.User_ID || "USER-001",
          name: apiUser.name || apiUser.userName || apiUser.User_Name || "User",
          role: normalizedRole,
          agentName: apiUser.agentName || apiUser.Agent_Name || "",
          labId: apiUser.labId || apiUser.Lab_ID || "",
          assignedArea: apiUser.assignedArea || apiUser.Area || "",
          email: apiUser.email || apiUser.Email || "",
        };

        console.log("normalizedUser:", normalizedUser);

        setCurrentUser(normalizedUser);
        setRole(normalizedRole);
        setActivePage(getDefaultPageForRole(normalizedRole));
      } catch (err) {
        console.error(err);

        const fallbackRole = ROLES.EXECUTIVE;
        const fallbackUser = {
          id: "FALLBACK-EXEC-001",
          name: "Executive",
          role: fallbackRole,
          agentName: "",
          labId: "",
          assignedArea: "",
          email: "",
        };

        setUserError(err.message || "Failed to load current user");
        setCurrentUser(fallbackUser);
        setRole(fallbackRole);
        setActivePage(getDefaultPageForRole(fallbackRole));
      } finally {
        setLoadingUser(false);
      }
    }

    loadUser();
  }, []);

  useEffect(() => {
  function handleSetActivePage(event) {
    if (event?.detail) {
      setActivePage(event.detail);
    }
  }

  window.addEventListener("primecare:setActivePage", handleSetActivePage);
  return () => {
    window.removeEventListener("primecare:setActivePage", handleSetActivePage);
  };
}, []);

  const pageTitle = useMemo(() => {
    if (!currentUser) return "PrimeCare Portal";
    return `PrimeCare Portal — ${currentUser.name}`;
  }, [currentUser]);

  if (loadingUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="rounded-2xl border bg-white p-6 shadow-sm text-center">
          <h2 className="text-xl font-semibold">Loading PrimeCare Portal...</h2>
          <p className="mt-2 text-gray-500">Resolving user access and role permissions.</p>
        </div>
      </div>
    );
  }

  if (!role || !activePage || !currentUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="rounded-2xl border bg-white p-6 shadow-sm text-center">
          <h2 className="text-xl font-semibold">Unable to load portal</h2>
          <p className="mt-2 text-gray-500">
            User role or navigation could not be initialized.
          </p>
        </div>
      </div>
    );
  }

  return (
    <PortalLayout
      role={role}
      activePage={activePage}
      setActivePage={setActivePage}
    >
      <div className="mb-4 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold">{pageTitle}</h1>
          <p className="text-sm text-gray-500">
            Logged in as <span className="font-medium">{currentUser.role}</span>
          </p>
          {userError ? (
            <p className="text-sm text-red-600 mt-1">
              Fallback access loaded: {userError}
            </p>
          ) : null}
        </div>
      </div>

      <PrimeCareWebPortal
        role={role}
        activePage={activePage}
        currentUser={currentUser}
      />
    </PortalLayout>
  );
}
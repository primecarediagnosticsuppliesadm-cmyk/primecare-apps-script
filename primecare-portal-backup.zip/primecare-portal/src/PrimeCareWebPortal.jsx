import { ROLES } from "./config/roles";

import DashboardPage from "./pages/DashboardPage";
import StockPage from "./pages/StockPage";
import AgentVisitPage from "./pages/AgentVisitPage";
import CollectionsPage from "./pages/CollectionsPage";
import AgentPage from "./AgentPage";
import LabsPage from "./pages/LabsPage";
import AdminDashboard from "./pages/AdminDashboard";
import ExecutiveControlTower from "./pages/ExecutiveControlTower";
import LabOrderingPage from "./pages/LabOrderingPage";
import AIInsightsPage from "./pages/AIInsightsPage";
import ReorderForecastPage from "./pages/ReorderForecastPage";
import AgentDashboard from "./pages/AgentDashboard";

function PlaceholderCard({ title, subtitle }) {
  return (
    <div className="rounded-2xl border bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="mt-2 text-gray-500">{subtitle}</p>
    </div>
  );
}

export default function PrimeCareWebPortal({ role, activePage, currentUser }) {
  if (role === ROLES.AGENT) {
    switch (activePage) {
      case "dashboard":
  return <AgentDashboard currentUser={currentUser} />;
      case "visits":
        return <AgentVisitPage currentUser={currentUser} />;

      case "collections":
        return <CollectionsPage currentUser={currentUser} />;

      case "labs":
  return <LabsPage currentUser={currentUser} />;

      default:
        return (
          <PlaceholderCard
            title="Agent Portal"
            subtitle="Agent-specific page is not mapped yet."
          />
        );
    }
  }

  if (role === ROLES.ADMIN) {
    switch (activePage) {
      case "dashboard":
  return <AdminDashboard currentUser={currentUser} />;

      case "visits":
        return <AgentPage currentUser={currentUser} />;

      case "collections":
        return <CollectionsPage currentUser={currentUser} />;

     case "labs":
  return <LabsPage currentUser={currentUser} />;

     case "inventory":
  return <ReorderForecastPage currentUser={currentUser} />;

      case "orders":
        return (
          <PlaceholderCard
            title="Orders"
            subtitle="Order management and fulfillment tracking."
          />
        );

      case "risk":
        return (
          <PlaceholderCard
            title="Credit & Risk"
            subtitle="Credit risky labs, collections pressure, and payment issues."
          />
        );

      case "performance":
        return (
          <PlaceholderCard
            title="Agent Performance"
            subtitle="Productivity, visits, collections, and field execution quality."
          />
        );

      default:
        return (
          <PlaceholderCard
            title="Admin Portal"
            subtitle="Admin page is not mapped yet."
          />
        );
    }
  }

  if (role === ROLES.EXECUTIVE) {
    switch (activePage) {
      case "dashboard":
  return <ExecutiveControlTower currentUser={currentUser} />;

     case "labs":
  return <LabsPage currentUser={currentUser} />;

     case "inventory":
  return <ReorderForecastPage currentUser={currentUser} />;

      case "orders":
        return (
          <PlaceholderCard
            title="Orders Overview"
            subtitle="Revenue movement, order pipeline, and order health."
          />
        );

      case "risk":
        return <CollectionsPage currentUser={currentUser} />;

      case "performance":
        return (
          <PlaceholderCard
            title="Business Performance"
            subtitle="Business-wide performance across operations and field execution."
          />
        );

      case "insights":
  return <AIInsightsPage />;

      default:
        return (
          <PlaceholderCard
            title="Executive Portal"
            subtitle="Executive page is not mapped yet."
          />
        );
    }
  }

  if (role === ROLES.LAB) {
    switch (activePage) {
      case "labOrders":
  return <LabOrderingPage currentUser={currentUser} />;

      default:
        return (
          <PlaceholderCard
            title="Lab Portal"
            subtitle="Lab page is not mapped yet."
          />
        );
    }
  }

  return null;
}

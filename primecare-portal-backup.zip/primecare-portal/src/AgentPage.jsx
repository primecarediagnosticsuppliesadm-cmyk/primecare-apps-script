import React, { useEffect, useMemo, useState } from "react";
import { motion } from "motion/react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import {
  Users,
  Activity,
  ClipboardCheck,
  ShoppingCart,
  PlusCircle,
} from "lucide-react";

import { getLabs, getRecentVisits, saveAgentVisit } from "@/api/primecareApi";
import { filterVisitsForUser, filterLabsForUser } from "@/utils/accessFilters";

function StatCard({ title, value, icon: Icon, subtitle }) {
  return (
    <Card className="rounded-2xl shadow-sm border-slate-200">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm text-slate-500">{title}</p>
            <h3 className="text-2xl font-bold mt-1 text-slate-900">{value}</h3>
            <p className="text-xs text-slate-500 mt-1">{subtitle}</p>
          </div>
          <div className="rounded-2xl p-3 bg-slate-50">
            <Icon className="w-5 h-5 text-slate-700" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AgentPage({ currentUser }) {
  const [labs, setLabs] = useState([]);
  const [visits, setVisits] = useState([]);
  const [loadingLabs, setLoadingLabs] = useState(true);
  const [loadingVisits, setLoadingVisits] = useState(true);
  const [statusMessage, setStatusMessage] = useState("");
  const [statusType, setStatusType] = useState("info");
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    agent: currentUser?.name || "Ravi",
    date: new Date().toISOString().slice(0, 10),
    labId: "",
    labName: "",
    area: currentUser?.assignedArea || "",
    visitType: "New Lead",
    samplesGiven: "",
    demoGiven: "No",
    labResponse: "Warm",
    soldValue: "",
    stockAvailable: "Yes",
    needsNewStock: "No",
    nextAction: "",
  });

  useEffect(() => {
    setForm((prev) => ({
      ...prev,
      agent: currentUser?.name || prev.agent,
      area: currentUser?.role === "agent" ? currentUser?.assignedArea || "" : prev.area,
    }));
  }, [currentUser]);

  useEffect(() => {
    async function loadLabs() {
      try {
        const res = await getLabs();
        if (!res.success) throw new Error(res.error || "Failed to load labs");

        const labRows = res.data?.labs || [];
        setLabs(labRows);
      } catch (err) {
        setStatusMessage(err.message || "Failed to load labs");
        setStatusType("error");
      } finally {
        setLoadingLabs(false);
      }
    }

    loadLabs();
  }, []);

  useEffect(() => {
    async function loadRecentVisits() {
      try {
        const res = await getRecentVisits();
        if (!res.success) throw new Error(res.error || "Failed to load visits");

        const rows = res.data?.visits || [];
        setVisits(
          rows.map((v) => ({
            id: v.id,
            agent: v.agent,
            date: v.date,
            labName: v.labName,
            area: v.area,
            visitType: v.visitType,
            samplesGiven: Number(v.samplesGiven || 0),
            demoGiven: v.demoGiven,
            labResponse: v.labResponse,
            soldValue: Number(v.soldValue || 0),
            stockAvailable: v.stockAvailable,
            needsNewStock: v.needsNewStock,
            nextAction: v.nextAction,
          }))
        );
      } catch (err) {
        setStatusMessage(err.message || "Failed to load recent visits");
        setStatusType("error");
      } finally {
        setLoadingVisits(false);
      }
    }

    loadRecentVisits();
  }, []);

  const visibleVisits = useMemo(() => {
    return filterVisitsForUser(visits, currentUser);
  }, [visits, currentUser]);

  const visibleLabs = useMemo(() => {
    return filterLabsForUser(labs, currentUser);
  }, [labs, currentUser]);

  const metrics = useMemo(() => {
    const totalVisits = visibleVisits.length;
    const demos = visibleVisits.filter((v) => v.demoGiven === "Yes").length;
    const converted = visibleVisits.filter((v) => v.labResponse === "Converted").length;
    const sales = visibleVisits.reduce((sum, v) => sum + Number(v.soldValue || 0), 0);
    return { totalVisits, demos, converted, sales };
  }, [visibleVisits]);

  function onLabChange(value) {
    const selected = visibleLabs.find((x) => x.labId === value);
    setForm((prev) => ({
      ...prev,
      labId: selected?.labId || "",
      labName: selected?.labName || "",
      area: selected?.area || prev.area,
    }));
  }

  async function addVisit() {
    if (!form.agent || !form.labName || !form.area) {
      setStatusMessage("Agent, lab name, and area are required");
      setStatusType("error");
      return;
    }

    const payload = {
      visitDate: form.date,
      agentName: form.agent,
      labId: form.labId,
      labName: form.labName,
      area: form.area,
      visitType: form.visitType,
      samplesGiven: Number(form.samplesGiven || 0),
      demoGiven: form.demoGiven,
      labResponse: form.labResponse,
      soldValue: Number(form.soldValue || 0),
      stockAvailable: form.stockAvailable,
      needsNewStock: form.needsNewStock,
      nextAction: form.nextAction,
      notes: "",
    };

    try {
      setSaving(true);

      const res = await saveAgentVisit(payload);
      if (!res.success) throw new Error(res.error || "Failed to save visit");

      const newVisit = {
        id: res.data?.visitId || `V-${Date.now()}`,
        agent: form.agent,
        date: form.date,
        labName: form.labName,
        area: form.area,
        visitType: form.visitType,
        samplesGiven: Number(form.samplesGiven || 0),
        demoGiven: form.demoGiven,
        labResponse: form.labResponse,
        soldValue: Number(form.soldValue || 0),
        stockAvailable: form.stockAvailable,
        needsNewStock: form.needsNewStock,
        nextAction: form.nextAction,
      };

      setVisits((prev) => [newVisit, ...prev]);

      setStatusMessage(`Saved successfully: ${res.data?.visitId || ""}`);
      setStatusType("success");

      setForm({
        agent: currentUser?.name || "Ravi",
        date: new Date().toISOString().slice(0, 10),
        labId: "",
        labName: "",
        area: currentUser?.assignedArea || "",
        visitType: "New Lead",
        samplesGiven: "",
        demoGiven: "No",
        labResponse: "Warm",
        soldValue: "",
        stockAvailable: "Yes",
        needsNewStock: "No",
        nextAction: "",
      });
    } catch (err) {
      setStatusMessage(err.message || "Failed to save visit");
      setStatusType("error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-4 gap-4">
        <StatCard title="Visits Logged" value={metrics.totalVisits} icon={Users} subtitle="Visible to this user" />
        <StatCard title="Demos Given" value={metrics.demos} icon={Activity} subtitle="Sample/demo coverage" />
        <StatCard title="Converted Labs" value={metrics.converted} icon={ClipboardCheck} subtitle="Converted into sales" />
        <StatCard title="Sales Captured" value={`₹${metrics.sales.toLocaleString()}`} icon={ShoppingCart} subtitle="Total sold value" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="rounded-2xl lg:col-span-1">
          <CardHeader>
            <CardTitle>Field Agent Update Form</CardTitle>
            <CardDescription>
              {currentUser?.role === "agent"
                ? `Only ${currentUser.name}'s labs and visits are visible here`
                : "Daily lab visit reporting"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input
              placeholder="Agent name"
              value={form.agent}
              onChange={(e) => setForm({ ...form, agent: e.target.value })}
              disabled={currentUser?.role === "agent"}
            />

            <Input
              type="date"
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
            />

            {loadingLabs ? (
              <div className="text-sm text-slate-500">Loading labs...</div>
            ) : (
              <Select value={form.labId} onValueChange={onLabChange}>
                <SelectTrigger><SelectValue placeholder="Select lab" /></SelectTrigger>
                <SelectContent>
                  {visibleLabs.map((lab) => (
                    <SelectItem key={lab.labId} value={lab.labId}>
                      {lab.labName} ({lab.labId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Input
              placeholder="Lab name"
              value={form.labName}
              onChange={(e) => setForm({ ...form, labName: e.target.value })}
            />

            <Input
              placeholder="Area / locality"
              value={form.area}
              onChange={(e) => setForm({ ...form, area: e.target.value })}
            />

            <Select value={form.visitType} onValueChange={(value) => setForm({ ...form, visitType: value })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="New Lead">New Lead</SelectItem>
                <SelectItem value="Follow-up">Follow-up</SelectItem>
                <SelectItem value="Closing">Closing</SelectItem>
                <SelectItem value="Collection">Collection</SelectItem>
                <SelectItem value="Support Visit">Support Visit</SelectItem>
              </SelectContent>
            </Select>

            <Input
              placeholder="Samples given"
              value={form.samplesGiven}
              onChange={(e) => setForm({ ...form, samplesGiven: e.target.value })}
            />

            <Select value={form.demoGiven} onValueChange={(value) => setForm({ ...form, demoGiven: value })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Yes">Demo given</SelectItem>
                <SelectItem value="No">No demo</SelectItem>
              </SelectContent>
            </Select>

            <Select value={form.labResponse} onValueChange={(value) => setForm({ ...form, labResponse: value })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Interested">Interested</SelectItem>
                <SelectItem value="Warm">Warm</SelectItem>
                <SelectItem value="Not Interested">Not Interested</SelectItem>
                <SelectItem value="Converted">Converted</SelectItem>
                <SelectItem value="Need Follow-up">Need Follow-up</SelectItem>
              </SelectContent>
            </Select>

            <Input
              placeholder="Sold value"
              value={form.soldValue}
              onChange={(e) => setForm({ ...form, soldValue: e.target.value })}
            />

            <Select value={form.stockAvailable} onValueChange={(value) => setForm({ ...form, stockAvailable: value })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Yes">Stock available</SelectItem>
                <SelectItem value="No">Stock not available</SelectItem>
                <SelectItem value="Partial">Partially available</SelectItem>
              </SelectContent>
            </Select>

            <Select value={form.needsNewStock} onValueChange={(value) => setForm({ ...form, needsNewStock: value })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Yes">Needs new stock</SelectItem>
                <SelectItem value="No">No new stock needed</SelectItem>
              </SelectContent>
            </Select>

            <Textarea
              placeholder="Next action / notes"
              value={form.nextAction}
              onChange={(e) => setForm({ ...form, nextAction: e.target.value })}
            />

            <Button className="w-full" onClick={addVisit} disabled={saving}>
              <PlusCircle className="w-4 h-4 mr-2" />
              {saving ? "Saving..." : "Save Agent Update"}
            </Button>

            {statusMessage && (
              <div
                className={`text-sm rounded-xl p-3 ${
                  statusType === "success"
                    ? "bg-green-100 text-green-700"
                    : "bg-red-100 text-red-700"
                }`}
              >
                {statusMessage}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="rounded-2xl lg:col-span-2">
          <CardHeader>
            <CardTitle>Lab Coverage and Visit Register</CardTitle>
            <CardDescription>
              {currentUser?.role === "agent"
                ? "Showing only this agent's visible visits"
                : "Daily field activity with demos, stock, and conversion status"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loadingVisits ? (
              <div className="text-sm text-slate-500">Loading recent visits...</div>
            ) : (
              <div className="space-y-3">
                {visibleVisits.length === 0 ? (
                  <div className="text-sm text-slate-500">No visible visits found.</div>
                ) : (
                  visibleVisits.map((visit) => (
                    <motion.div key={visit.id} layout className="border rounded-2xl p-4 space-y-2">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                        <div>
                          <div className="font-semibold text-slate-900">{visit.labName}</div>
                          <div className="text-sm text-slate-500">
                            {visit.area} • {visit.agent} • {visit.date}
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <Badge>{visit.visitType}</Badge>
                          <Badge variant="secondary">Response: {visit.labResponse}</Badge>
                          <Badge variant="secondary">Demo: {visit.demoGiven}</Badge>
                          <Badge variant="secondary">Stock: {visit.stockAvailable}</Badge>
                          {visit.needsNewStock === "Yes" && (
                            <Badge variant="destructive">Needs stock</Badge>
                          )}
                        </div>
                      </div>

                      <div className="grid md:grid-cols-3 gap-3 text-sm text-slate-700">
                        <div>
                          Samples given: <span className="font-medium">{visit.samplesGiven}</span>
                        </div>
                        <div>
                          Sold value: <span className="font-medium">₹{Number(visit.soldValue || 0).toLocaleString()}</span>
                        </div>
                        <div>
                          Next action: <span className="font-medium">{visit.nextAction || "-"}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}